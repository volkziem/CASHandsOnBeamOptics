% SB.m, sector bend
   function out=SB(L,phi);
out=eye(3);
if abs(phi)<1e-8
  out(1,2)=L;
 else
  rho=L/phi;
  out(1:2,1:3)=[cos(phi),rho*sin(phi),rho*(1-cos(phi)); ...
                -sin(phi)/rho,cos(phi),sin(phi)];
end
