% D.m, drift space
function out=D(L)
out=eye(4);
out(1,2)=L;
out(3,4)=L;
