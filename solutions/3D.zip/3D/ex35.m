% ex35.m, trajectory with delta=0,1e-3,3e-3
ex34;  % prepare the lattice
%..first build the beamline of six FODOs
beamline=repmat(fodo,6,1);
nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);  % calculate matrices
%.............plot orbit with different momenta
xpos=zeros(nmat,1);  % allocate array to store values to display
delta=3e-3;          % <---change delta here
x0=[0;0;delta];   % change third component, which is dp/p
for k=1:nmat
  x=Racc(:,:,k)*x0;
  xpos(k)=x(1);
end
plot(spos,xpos);
xlabel('s [m]'); ylabel('x [m]')
