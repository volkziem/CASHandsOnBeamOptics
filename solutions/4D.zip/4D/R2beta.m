% R2beta.m
function [Q,alpha,beta,gamma]=R2beta(Rturn)
mu2=acos(0.5*trace(Rturn));
if (Rturn(1,2)<0) mu2=2*pi-mu2; end
Q=mu2/(2*pi);
beta=Rturn(1,2)/sin(mu2);
alpha=(0.5*(Rturn(1,1)-Rturn(2,2)))/sin(mu2);
gamma=(1+alpha^2)/beta;
  