% ex38.m, periodic dispersion function in one cell
ex34;  % prepare the lattice
D0=(eye(2)-Rturn(1:2,1:2))\Rturn(1:2,3)
D0=[D0;1];           % patch a '1' into the third component
Dx=zeros(nmat,1);    % allocate array to store values to display
for k=1:nmat
  x=Racc(:,:,k)*D0;
  Dx(k)=x(1);
end
plot(spos,Dx);
xlabel('s [m]'); ylabel('D_x [m]')
