% SOL.m, solenoid matrix
% Hands-on accelerator physics, Equation 3.36
function out=SOL(L,ks)
if (abs(ks)<1e-10) ks=1e-10; end  % catch zero
phis=ks*L/2; c=cos(phis); s=sin(phis);
Qs=[c, 2*s/ks; -ks*s/2, c];
Rr=[c,0,s,0;
    0,c,0,s;
   -s,0,c,0;
    0,-s,0,c];
out=Rr*[Qs,zeros(2,2);zeros(2,2),Qs];