% ex41.m, 90-60 FODO lattice with a bending magnet
clear all; % close all

L=2;
FF=1.54;   % start with same values
FD=1.84;        
phi=10/10;  % ten slices
fodo=[2,   1,    0,  2*FF;    
       1,   5, L/20,  0; 
       4,  10, 0.1,   phi;     
       1,   5, L/20,  0;      
       2,   1,    0, -FD;      
       1,   5, L/20,  0; 
       4,  10, 0.1,   phi;     
       1,   5, L/20,  0;      
       2,   1,    0,  2*FF];

beamline=fodo;   

nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);  % calculate matrices
Rturn=Racc(:,:,end);             % full turn matrix

[Qx,alphax0,betax0,gammax0]=R2beta(Rturn(1:2,1:2));  % only 2x2 horizontal part
[Qy,alphay0,betay0,gammay0]=R2beta(Rturn(3:4,3:4));  % only 2x2 vertical part

Q=[Qx,Qy]      % display the tune, should be 1/4,1/6, but 0.25xxx,0.16xxx is OK

