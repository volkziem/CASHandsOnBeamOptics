% DD.m, drift space
function out=D(L)
out=eye(3);
out(1,2)=L;

