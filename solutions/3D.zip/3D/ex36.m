% ex36.m, beam size with sigmap=0, reference
ex34;  % prepare the lattice
%..first build the beamline of six FODOs
beamline=repmat(fodo,6,1);
nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);  % calculate matrices
%.........plot the beam sizes with different momentum spread
sigma0=eye(3);
eps0=1e-6; % 1 mm-mrad emittance
sigma0(1:2,1:2)=eps0*[beta0, -alpha0; -alpha0,gamma0];
sigp=1e-3;             % momentum spread
sigma0(3,3)=sigp^2;    % momentum spread squared
sigmax=zeros(nmat,1);  % allocate array
for k=1:nmat
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   sigmax(k)=sqrt(sigma(1,1));
end
plot(spos,sigmax)
xlabel('s [m]'); ylabel('\sigma_x [m]')

