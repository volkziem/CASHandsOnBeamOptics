% ex43.m, introduce transfer matrix for solenoid
% check SOL.m and calcmat2.m for code 20
clear all; close all;
F=2.5;   % focal length of the quadrupoles
fodo=[ 1,  5,  0.2,  0;    % 5* D(L/10)
	     2,  1,  0.0, -F;    % QD
	     1,  3,  0.2,  0;    % 3* D(L/10) 
      20,  4,  0.2,  1;    % SOL
       1,  3,  0.2,  0;    % 3* D(L/10)    
	     2,  1,  0.0,  F;    % QF
       1,  5,  0.2,  0];   % 5* D(L/10) 
beamline=fodo;
[Racc,spos,nmat,nlines]=calcmat2(beamline);

x0=[0.001;0;0;0];     % 1 mm offset at start
data=zeros(nmat,2);   % allocate memory
for k=1:nmat          
  x=Racc(:,:,k)*x0;
  data(k,1)=x(1);  % store the horizontal position
  data(k,2)=x(3);  % vertical position
end
plot(spos,1e3*data(:,1),spos,1e3*data(:,2),'--')
xlabel('s [m]'); ylabel(' x,y [mm]'); legend('x','y')
xlim([spos(1),spos(end)])
