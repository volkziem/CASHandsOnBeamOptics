% ex34.m, 3D, FODO60 with sector bends
clear all; % close all
L=2;
F=2.262;    % copy from ex32.m
phi=10/10;  % ten slices
fodo=[2,   1,    0,  2*F;    
       1,   5, L/20,  0; 
       4,  10, 0.1,   phi;     
       1,   5, L/20,  0;      
       2,   1,    0, -F;      
       1,   5, L/20,  0; 
       4,  10, 0.1,   phi;     
       1,   5, L/20,  0;      
       2,   1,    0,  2*F];
beamline=fodo;   
nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);  % calculate matrices
Rturn=Racc(:,:,end);             % full turn matrix
[Q,alpha0,beta0,gamma0]=R2beta(Rturn(1:2,1:2));  % only 2x2 transverse part
% here we know the periodic beta functions of the FODO cell
% needed for part 
Q=Q      % display the tune, should be 1/6
