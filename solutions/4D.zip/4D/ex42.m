% ex42.m, long fodo line with mismatch
clear all; close all
L=2;
F=2;
fodo=[ 	1,  5, L/10,  0;     
	      2,  1,    0, -F;     
	      1, 10, L/10,  0;      
	      2,   1,   0,  F;
        1,  5, L/10,  0; ];
beamline=fodo; 

[Racc,spos]=calcmat2(beamline);   % sets up all transfer matrices
Rturn=Racc(:,:,end);             % full-turn matrix
[Qx,alphax0,betax0,gammax0]=R2beta(Rturn(1:2,1:2));  % only 2x2 horizontal part
[Qy,alphay0,betay0,gammay0]=R2beta(Rturn(3:4,3:4));  % only 2x2 vertical part

Q=[Qx,Qy]      % display the tune, should be 1/4,1/6, but 0.25xxx,0.16xxx is OK

%.......build the initial matrix
eps=1;  % just want to see the beta functions
sigma0=zeros(4,4);
sigma0(1:2,1:2)=eps*[betax0,-alphax0;-alphax0,gammax0];
sigma0(3:4,3:4)=eps*[betay0,-alphay0;-alphay0,gammay0];

%....a)  unperturbed beamline
if 1   % change to 1 to see the unperturbed lattice 
beamline=repmat(fodo,8,1);
nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);   % sets up all transfer matrices
beta=zeros(nmat,2);
for k=1:nmat
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   beta(k,1)=sigma(1,1);
   beta(k,2)=sigma(3,3);
end
plot(spos,beta(:,1),spos,beta(:,2),'--','LineWidth',2)
xlabel('s [m]'); ylabel('\beta_x,\beta_y [m]'); 
legend('\beta_x','\beta_y')
xlim([0,spos(end)]); ylim([0,10]); set(gca,'FontSize',16)
figure
end

%....b) change a quad by 10%
fodobad=fodo;
fodobad(4,4)=fodobad(4,4)*1.1;  % increase focal length by 10 %
beamline=[fodobad;repmat(fodo,7,1)];
nmat=sum(beamline(:,2))+1;
[Racc,spos]=calcmat2(beamline);   % sets up all transfer matrices
beta=zeros(nmat,2);
for k=1:nmat
   sigma=Racc(:,:,k)*sigma0*Racc(:,:,k)';
   beta(k,1)=sigma(1,1);
   beta(k,2)=sigma(3,3);
end
plot(spos,beta(:,1),spos,beta(:,2),'--','LineWidth',2)
xlabel('s [m]'); ylabel('\beta_x,\beta_y [m]');
legend('\beta_x','\beta_y')
xlim([0,spos(end)]); ylim([0,10]); set(gca,'FontSize',16)